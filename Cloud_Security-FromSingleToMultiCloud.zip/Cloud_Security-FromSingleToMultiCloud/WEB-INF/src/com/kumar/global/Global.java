/**
 * 
 */
package com.kumar.global;

public interface Global 
{
	// Database Related Constants
	public static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";	
	public static final String JDBC_HOST_URL_WITH_DBNAME = "jdbc:mysql://localhost:3306/multi_cloud";
	public static final String DATABASE_USERNAME = "root";
	public static final String DATABASE_PASSWORD = "admin";
	public static final String SERVER = "dhsinformatics.com";
	public static final String FTP_USER = "BHOOMIKASURESH33";
	public static final String FTP_PASS = "*India123";
	public static final String SERVER1 = "celestialv.com";
	public static final String FTP_USER1 = "BHOOMIKASURESH33";
	public static final String FTP_PASS1 = "*India123";
}
